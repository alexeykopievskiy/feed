export default (state, payload) => ({ ...state, ...payload });
