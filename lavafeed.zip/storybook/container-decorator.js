import React from 'react';

export default story => <div style={{ padding: 20 }}>{story()}</div>;
